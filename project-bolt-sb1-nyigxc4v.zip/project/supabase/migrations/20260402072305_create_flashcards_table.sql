/*
  # Create flashcards table for biology app

  1. New Tables
    - `flashcards`
      - `id` (uuid, primary key)
      - `term` (text) - The biology term to learn
      - `definition` (text) - The definition of the term
      - `category` (text) - Category of the flashcard (e.g., 'endocrinology')
      - `created_at` (timestamptz) - When the flashcard was created
  
  2. Security
    - Enable RLS on `flashcards` table
    - Add policy for anyone to read flashcards (public educational content)
*/

CREATE TABLE IF NOT EXISTS flashcards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  term text NOT NULL,
  definition text NOT NULL,
  category text NOT NULL DEFAULT 'general',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE flashcards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read flashcards"
  ON flashcards
  FOR SELECT
  TO anon, authenticated
  USING (true);